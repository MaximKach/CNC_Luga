import os
from dotenv import load_dotenv

# Загружаем переменные окружения из файла .env
load_dotenv()

# Получаем токены и ID из .env
TOKEN = os.getenv("TBOT_TOKEN")
YANDEX_API_KEY = os.getenv("YANDEX_API_KEY")
FOLDER_ID = os.getenv("YANDEX_FOLDER_ID")

# Проверяем, что все ключи загружены
if not TOKEN or not YANDEX_API_KEY or not FOLDER_ID:
    raise ValueError("❌ Ошибка: Не загружены ключи API. Проверь .env файл!")